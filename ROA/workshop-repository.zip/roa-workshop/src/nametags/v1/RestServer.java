package nametags.v1;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ErrorHandler;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 * Embedded Jetty server to run NameTags REST service.
 *
 * JVM properties: jetty.port - port to run service on (default: 8080)
 */
public class RestServer {
    static {
        System.setProperty("file.encoding", "utf-8");
    }

    public static void main(String[] args) throws Exception {
        Server server = new Server(Integer.getInteger("jetty.port", 8080));

        try {
            WebAppContext webapp = new WebAppContext();
            webapp.setContextPath("/");
            webapp.setWar("./");
            webapp.getSecurityHandler().setLoginService(new MockLoginService());
            webapp.setErrorHandler(new ErrorHandler() {
                public void handle(String target, Request baseRequest,
                        HttpServletRequest request, HttpServletResponse response)
                        throws IOException {
                }
            });
            server.setHandler(webapp);
            server.start();
            server.join();
        } finally {
            server.stop();
        }
    }
}
