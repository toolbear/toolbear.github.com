/**
 * 
 */
package nametags.v1;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class TagDAO {
    static TagDAO find(String photoDigest, String personName)
            throws SQLException, URISyntaxException {
        TagDAO tag = null;
        Connection connection = DB.connect();
        PreparedStatement statement = connection
                .prepareStatement("select photo_digest, person_name, coordinates, user_name, uri from tags, photos where photos.digest = tags.photo_digest and photo_digest = ? and person_name = ?");
        statement.setString(1, photoDigest);
        statement.setString(2, personName);
        ResultSet results = statement.executeQuery();
        if (results.next()) {
            tag = new TagDAO(results.getString(1), results.getString(2),
                    results.getString(3).split(","), results.getString(4),
                    new URI(results.getString(5)));
        }
        connection.close();
        return tag;
    }

    final String photoDigest;
    final String personName;
    private final String[] coordinates;
    final String userName;
    final URI imageUri;

    TagDAO(String photoDigest, String personName, int[] coordinates,
            String userName, URI imageUri) {
        this(photoDigest, personName, new String[] {
            ""+coordinates[0], 
            ""+coordinates[1], 
            ""+coordinates[2], 
            ""+coordinates[3] 
        }, userName, imageUri);
    }

    TagDAO(String photoDigest, String personName, String[] coordinates,
            String userName, URI imageUri) {
        this.photoDigest = photoDigest;
        this.personName = personName;
        this.coordinates = coordinates;
        this.userName = userName;
        this.imageUri = imageUri;
    }

    void insert() throws SQLException {
        Connection connection = DB.connect();
        PreparedStatement statement = connection
                .prepareStatement("insert into tags (photo_digest, person_name, coordinates, user_name) values(?,?,?,?)");
        statement.setString(1, photoDigest);
        statement.setString(2, personName);
        statement.setString(3, coordinates());
        statement.setString(4, userName);
        statement.execute();
        statement.close();
        connection.commit();
    }
    
    String coordinates() {
        return join(coordinates);
    }

    private String join(String[] coordinates) {
        StringBuilder builder = new StringBuilder();
        for (String coordinate : coordinates) {
            builder.append(coordinate);
            builder.append(",");
        }
        return builder.toString().replaceAll(",$", "");
    }
}