package nametags.v1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DB {
    static {
        try {
            Class.forName("org.hsqldb.jdbcDriver");
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:hsqldb:file:db/nametags;ifexists=true", "SA", null);
    }
}
