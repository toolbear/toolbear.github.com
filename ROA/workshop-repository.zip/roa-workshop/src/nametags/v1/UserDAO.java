package nametags.v1;

import java.sql.*;

class UserDAO {
    final String userName;
    final String password;

    public static UserDAO find(String userName) throws SQLException {
        UserDAO user = null;
        Connection connection = DB.connect();
        PreparedStatement statement = connection.prepareStatement(
                "select user_name, password from users where user_name = ?");
        statement.setString(1, userName);
        ResultSet results = statement.executeQuery();
        if (results.next()) {
            user = new UserDAO(results.getString(1), results.getString(2));
        }
        connection.close();
        return user;
    }

    void insert() throws SQLException {
        Connection connection = DB.connect();
        PreparedStatement statement = connection.prepareStatement(
                "insert into users (user_name, password) values(?,?)");
        statement.setString(1, userName);
        statement.setString(2, password);
        statement.execute();
        statement.close();
        connection.commit();
    }

    void update() throws SQLException {
        Connection connection = DB.connect();
        PreparedStatement statement = connection.prepareStatement(
                "update users set password = ? where user_name = ?");
        statement.setString(1, password);
        statement.setString(2, userName);
        statement.execute();
        statement.close();
        connection.commit();
    }

    UserDAO(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
}