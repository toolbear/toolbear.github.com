/**
 * Mocks for Jetty so we can have HTTP Authentication without having to
 * to integrate a real login service such as user/role DB tables, LDAP, etc..
 */
package nametags.v1;

import java.security.Principal;

import javax.security.auth.Subject;

import org.eclipse.jetty.security.IdentityService;
import org.eclipse.jetty.security.LoginService;
import org.eclipse.jetty.security.RunAsToken;
import org.eclipse.jetty.server.UserIdentity;

final class MockLoginService implements LoginService, IdentityService {
    public IdentityService getIdentityService() { return this; }

    public String getName() { return "MockLoginService"; }

    public UserIdentity login(final String username, Object password) {
        return new UserIdentity() {
            public Subject getSubject() { return null; }

            public Principal getUserPrincipal() {
                return new Principal() {
                    public String getName() {
                        return username;
                    }
                };
            }

            public boolean isUserInRole(String a, Scope b) { return true; }
        };
    }

    public void setIdentityService(IdentityService a) {}

    public boolean validate(UserIdentity a) { return true; }

    public Object associate(UserIdentity a) { return null; }

    public void disassociate(Object a) {}

    public UserIdentity getSystemUserIdentity() { return null; }

    public RunAsToken newRunAsToken(String a) { return null; }

    public UserIdentity newUserIdentity(Subject a, Principal b, String[] c) { return null; }

    public Object setRunAs(UserIdentity a, RunAsToken b) { return null; }

    public void unsetRunAs(Object a) {}
}