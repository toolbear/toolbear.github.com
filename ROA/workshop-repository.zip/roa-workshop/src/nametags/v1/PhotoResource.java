package nametags.v1;

import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import com.sun.jersey.api.NotFoundException;

@Path("/photo")
@Produces("application/xml")
public class PhotoResource {
    @Context
    UriInfo uriInfo;

    @GET
    @Path("{uri-hash}")
    public Response getPhoto(@PathParam("uri-hash") String digest) throws SQLException, URISyntaxException {
        PhotoDAO photo = PhotoDAO.find(digest);
        if (photo == null) {
            throw new NotFoundException();
        }
        StringBuilder xml = new StringBuilder();
        xml.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        xml.append("<photo>\n");
        xml.append("<img src=\""); xml.append(photo.uri); xml.append("\"/>\n");
        for (TagDAO tag : photo.tags) {
            xml.append("<area shape=\"rect\" coords=\"");
            xml.append(tag.coordinates());
            xml.append("\" href=\"");
            xml.append(uriInfo.getAbsolutePathBuilder().path(tag.personName).build());
            xml.append("\">");
            xml.append(tag.personName);
            xml.append("</area>\n");
        }
        xml.append("</photo>\n");
        return Response.ok().entity(xml.toString()).build();
    }
}
