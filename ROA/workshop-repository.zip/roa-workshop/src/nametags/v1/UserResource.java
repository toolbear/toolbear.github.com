package nametags.v1;

import static javax.ws.rs.core.Response.Status.*;

import java.net.URI;
import java.security.Principal;
import java.sql.SQLException;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/user/{user-name}")
public class UserResource {
    @Context
    UriInfo uriInfo;
    @Context
    SecurityContext security;

    @GET
    public Response getUser(@PathParam("user-name") String userName)
            throws SQLException {
        if (UserDAO.find(userName) != null) {
            return Response.noContent().build();
        } else {
            return Response.status(NOT_FOUND).build();
        }
    }

    @PUT
    @Consumes("application/x-www-form-urlencoded")
    public Response createUser(@PathParam("user-name") String userName,
            @FormParam("password") String password) throws SQLException {
        UserDAO user = UserDAO.find(userName);
        if (user != null) {
            Principal principal = security.getUserPrincipal();
            if (principal == null) {
                return Response.status(CONFLICT).build();
            } else if (!userName.equals(principal.getName())) {
                return Response.status(UNAUTHORIZED)
                        .header("WWW-Authenticate", "BASIC").build();
            }
        }
        if (password == null || password.length() == 0) {
            return Response.status(BAD_REQUEST)
                .entity("password required\n").build();
        }
        if (user == null) {
            new UserDAO(userName, password).insert();
            URI uri = uriInfo.getAbsolutePath();
            return Response.created(uri).build();
        } else {
            new UserDAO(userName, password).update();
            return Response.noContent().build();
        }
    }
}
