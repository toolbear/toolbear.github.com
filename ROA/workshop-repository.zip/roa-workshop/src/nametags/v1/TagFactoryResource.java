package nametags.v1;

import static javax.ws.rs.core.Response.Status.*;
import static nametags.v1.JunkDrawer.uriToHash;

import java.io.*;
import java.net.*;
import java.security.*;
import java.sql.SQLException;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/photos")
public class TagFactoryResource {
    @Context
    UriInfo uriInfo;
    @Context
    SecurityContext security;

    @POST
    @Consumes("application/x-www-form-urlencoded")
    public Response createTag(@FormParam("person-name") String personName,
            @FormParam("photo-uri") URI photoUri,
            @FormParam("xmin") int xmin, @FormParam("ymin") int ymin,
            @FormParam("xmax") int xmax, @FormParam("ymax") int ymax)
            throws URISyntaxException,
            UnsupportedEncodingException, SQLException {
        Principal principal = security.getUserPrincipal();
        if (principal == null) {
            return Response.status(UNAUTHORIZED).header(
                    "WWW-Authenticate", "BASIC").build();
        }

        int[] coordinates = new int[] { xmin, ymin, xmax, ymax };
        String digest = uriToHash(photoUri);

        if (TagDAO.find(digest, personName) != null) {
            return Response.status(CONFLICT).build();
        }
        if (PhotoDAO.find(photoUri) == null) {
            new PhotoDAO(digest, photoUri).insert();
        }
        new TagDAO(digest, personName, coordinates,
            principal.getName(), photoUri).insert();

        UriBuilder baseUri = uriInfo.getBaseUriBuilder();
        URI tagUri = baseUri.path("photo").path(digest).path(personName)
            .build(); 
        return Response.created(tagUri).build();
    }
}
