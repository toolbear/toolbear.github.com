package nametags.v1;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URI;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class JunkDrawer {
    private static final int BASE_36 = 36;

    /**
     * Returns MD5 digest of the URI in base-36. Result is shorter than base-64
     * and uses no URI special characters.
     */
    public static String uriToHash(String uri) {
        return md5(uri).toString(BASE_36);
    }
    
    public static String uriToHash(URI uri) {
        return uriToHash(uri.toString());
    }

    private static BigInteger md5(String text) {
        try {
            byte[] hash = MessageDigest.getInstance("MD5").digest(
                text.getBytes("UTF-8"));
            return new BigInteger(1, hash);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        } catch (UnsupportedEncodingException ex) {
            throw new RuntimeException(ex);
        }
    }
}
