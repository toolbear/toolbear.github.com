package nametags.v1;

import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

final class PhotoDAO {
    static PhotoDAO find(String digest) throws SQLException,
            URISyntaxException {
        PhotoDAO photo = null;
        Connection connection = DB.connect();
        PreparedStatement statement = connection
                .prepareStatement("select digest, uri from photos where digest = ?");
        statement.setString(1, digest);
        ResultSet results = statement.executeQuery();
        if (results.next()) {
            photo = new PhotoDAO(results.getString(1), new URI(results
                    .getString(2)));
            loadTags(connection, photo);
        }
        connection.close();
        return photo;
    }

    static PhotoDAO find(URI uri) throws SQLException, URISyntaxException {
        PhotoDAO photo = null;
        Connection connection = DB.connect();
        PreparedStatement statement = connection
                .prepareStatement("select digest, uri from photos where uri = ?");
        statement.setString(1, uri.toString());
        ResultSet results = statement.executeQuery();
        if (results.next()) {
            photo = new PhotoDAO(results.getString(1), new URI(results.getString(2)));
            loadTags(connection, photo);
        }
        connection.close();
        return photo;
    }

    private static void loadTags(Connection connection, PhotoDAO photo)
            throws SQLException {
        PreparedStatement statement = connection.prepareStatement("select person_name, coordinates, user_name from tags where photo_digest = ?");
        statement.setString(1, photo.digest);
        ResultSet results = statement.executeQuery();
        while (results.next()) {
            TagDAO tag = new TagDAO(photo.digest, results.getString(1),
                    results.getString(2).split(","), results.getString(3),
                    photo.uri);
            photo.tags.add(tag);
        }
    }

    final String digest;
    final URI uri;
    final List<TagDAO> tags = new ArrayList<TagDAO>();

    PhotoDAO(String digest, URI uri) {
        this.digest = digest;
        this.uri = uri;
    }

    void insert() throws SQLException {
        Connection connection = DB.connect();
        PreparedStatement statement = connection
                .prepareStatement("insert into photos (digest, uri) values(?,?)");
        statement.setString(1, digest);
        statement.setString(2, uri.toString());
        statement.execute();
        statement.close();
        connection.commit();
    }
}