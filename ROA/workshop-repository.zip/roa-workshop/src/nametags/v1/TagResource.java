package nametags.v1;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import com.sun.jersey.api.NotFoundException;

@Path("/photo/{uri-hash}/{person-name}")
@Produces("application/xml")
public class TagResource {
    @Context
    UriInfo uriInfo;

    @GET
    public Response getTagForPersonInPhoto(@PathParam("uri-hash") String photoDigest,
            @PathParam("person-name") String personName) throws SQLException, URISyntaxException {
        TagDAO tag = TagDAO.find(photoDigest, personName);
        if (tag == null) {
            throw new NotFoundException();
        }
        
        UriBuilder baseUri = uriInfo.getBaseUriBuilder();
        URI photoUri = baseUri.path("photo").path(tag.photoDigest).build();
        return Response.ok().entity(
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<tag>\n" +
            "<img src=\"" + tag.imageUri + "\"/>\n" +
            "<area shape=\"rect\" coords=\"" + tag.coordinates() +"\">" +
            tag.personName +
            "</area>\n" +
            "<link rel=\"photo\" href=\"" + photoUri + "\"/>\n" +
            "</tag>\n"
        ).build();
    }
}
