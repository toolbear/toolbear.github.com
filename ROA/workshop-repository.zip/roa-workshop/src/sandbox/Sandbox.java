package sandbox;

import static workshop.HTTP.*;

public final class Sandbox {
    public static void main(String[] args) {
        POST(
            "http://localhost:8080/v1/photos",
            basicAuth(prompt("username: "), prompt("password: ")),
            "application/x-www-form-urlencoded",
            "photo-uri=http://nps.gov/mount-rushmore.jpg&" +
            "person-name=George Washington&" +
            "xmin=340&" +
            "ymin=365&" +
            "xmax=940&" +
            "ymax=979"
        );

        POST(
            "http://localhost:8080/v1/photos",
            basicAuth(prompt("username: "), prompt("password: ")),
            "application/x-www-form-urlencoded",
            "photo-uri=http://nps.gov/mount-rushmore.jpg&" +
            "person-name=Abraham Lincoln&" +
            "xmin=1923&" +
            "ymin=661&" +
            "xmax=2367&" +
            "ymax=1303"
        );

//        GET("<Newly created Tag URI from Location header>");

//      GET("<Photo URI from link in Tag>");
        
//      GET("<Tag URI of one of the other tags on the photo>");
        
    }
}
